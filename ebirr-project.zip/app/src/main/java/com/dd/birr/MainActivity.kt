package com.dd.birr

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var box: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 70, 40, 70)
        }
        setContentView(ScrollView(this).apply { addView(box) })
        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        draw()
    }

    private fun askPermissions() {
        val need = mutableListOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        draw()
    }

    private fun text(s: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setPadding(0, 18, 0, 6)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun button(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s; setOnClickListener { onClick() }
    }

    private fun draw() {
        box.removeAllViews()
        box.addView(text("ብር ማሳያ", 26f, true))

        val smsOk = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
        if (!smsOk) {
            box.addView(text("የ SMS ፈቃድ አልተሰጠም። መተግበሪያው ያለ እሱ አይሰራም።"))
            box.addView(button("ፈቃድ ስጥ") { askPermissions() })
        }
        if (Build.VERSION.SDK_INT >= 34) {
            box.addView(button("ሙሉ ማያ ፈቃድ (ስልክ ተቆልፎ እንዲያበራ)") {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
            })
        }

        val fs = Store.fontSize(this)
        val fsLabel = text("የፊደል መጠን: $fs")
        box.addView(fsLabel)
        box.addView(SeekBar(this).apply {
            max = 80; progress = fs - 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, v: Int, u: Boolean) {
                    fsLabel.text = "የፊደል መጠን: " + (v + 40)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { Store.setFontSize(this@MainActivity, s.progress + 40) }
            })
        })

        val tcName = Store.TEXT_COLORS.firstOrNull { it.second == Store.textColor(this) }?.first ?: ""
        box.addView(button("የፊደል ቀለም: $tcName") {
            AlertDialog.Builder(this).setTitle("የፊደል ቀለም")
                .setItems(Store.TEXT_COLORS.map { it.first }.toTypedArray()) { _, i ->
                    Store.setTextColor(this, Store.TEXT_COLORS[i].second); draw()
                }.show()
        })
        val bcName = Store.BG_COLORS.firstOrNull { it.second == Store.bgColor(this) }?.first ?: ""
        box.addView(button("የጀርባ ቀለም: $bcName") {
            AlertDialog.Builder(this).setTitle("የጀርባ ቀለም")
                .setItems(Store.BG_COLORS.map { it.first }.toTypedArray()) { _, i ->
                    Store.setBgColor(this, Store.BG_COLORS[i].second); draw()
                }.show()
        })

        box.addView(Switch(this).apply {
            text = "ስሙን እና መጠኑን ጮክ ብሎ አንብብ"; isChecked = Store.tts(this@MainActivity)
            setPadding(0, 24, 0, 24)
            setOnCheckedChangeListener { _, v -> Store.setTts(this@MainActivity, v) }
        })

        box.addView(text("የመልዕክት ምንጮች", 20f, true))
        val list = Store.sources(this)
        if (list.isEmpty()) box.addView(text("ምንም ምንጭ አልተጨመረም። ከታች ጨምር።"))
        list.forEach { s ->
            box.addView(text(s.id, 18f, true))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(Switch(this).apply {
                text = "ገቢ  "; isChecked = s.inn
                setOnCheckedChangeListener { _, v -> s.inn = v; Store.saveSources(this@MainActivity, list) }
            })
            row.addView(Switch(this).apply {
                text = "  ወጪ  "; isChecked = s.out
                setOnCheckedChangeListener { _, v -> s.out = v; Store.saveSources(this@MainActivity, list) }
            })
            row.addView(button("አስወግድ") {
                list.remove(s); Store.saveSources(this, list); draw()
            })
            box.addView(row)
        }
        box.addView(button("ምንጭ ጨምር") { addSource() })
        box.addView(button("ሞክር: ገቢ") { test(Parser.SAMPLE_IN) })
        box.addView(button("ሞክር: ወጪ") { test(Parser.SAMPLE_OUT) })
    }

    private fun test(sms: String) {
        val p = Parser.parse(sms) ?: return
        startActivity(Notifier.intentFor(this, p))
    }

    private fun addSource() {
        if (checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "መጀመሪያ የ SMS ፈቃድ ስጥ", Toast.LENGTH_LONG).show()
            return
        }
        val found = linkedSetOf<String>()
        try {
            contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address"), null, null, "date DESC")?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 800) {
                    c.getString(0)?.let { found.add(it) }
                    n++
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "መልዕክቶችን ማንበብ አልተቻለም", Toast.LENGTH_LONG).show()
            return
        }
        val have = Store.sources(this).map { it.id.lowercase() }
        val opts = found.filter { it.lowercase() !in have }
            .sortedBy { a -> a.all { it.isDigit() || it == '+' } }
            .take(60)
        if (opts.isEmpty()) {
            Toast.makeText(this, "የሚጨመር conversation አልተገኘም", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Conversation ምረጥ")
            .setItems(opts.toTypedArray()) { _, i ->
                val l = Store.sources(this)
                l.add(Src(opts[i], true, false))
                Store.saveSources(this, l)
                draw()
            }.show()
    }
}
