package com.dd.birr

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Notifier {
    fun intentFor(c: Context, p: Payment): Intent =
        Intent(c, PaymentActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("income", p.income)
            putExtra("amount", p.amount)
            putExtra("name", p.name)
            putExtra("balance", p.balance)
        }

    fun show(c: Context, p: Payment) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("pay", "ክፍያዎች", NotificationManager.IMPORTANCE_HIGH)
        )
        val pi = PendingIntent.getActivity(
            c, (System.currentTimeMillis() % 100000).toInt(), intentFor(c, p),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val sign = if (p.income) "+" else "-"
        val n = Notification.Builder(c, "pay")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(sign + p.amount + " ብር")
            .setContentText(p.name)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
    }
}
