package com.dd.birr

import java.util.Locale

data class Payment(val income: Boolean, val amount: String, val name: String, val balance: String)

object Parser {
    const val SAMPLE_IN = "[-EBIRR-COOPay-] Ref:2912660120 Confirmed. ETB1,000 Received from melat mellion legese (911930123),Date: 09/11/26 09:30:25, your new A/C balance is ETB1,103.8"
    const val SAMPLE_OUT = "[-EBIRR-COOPay-] Transfer ID :2913924522 ETB1,000, Charges: ETB2 with VAT: ETB0.40 sent to Andualem neguse seboka(0988384318) at 09/11/2026 16:15:26:277, your balance is ETB101.4."

    private val recv = Regex("""ETB\s?([\d,\.]+)\s+Received from\s+(.+?)\s*\(""", RegexOption.IGNORE_CASE)
    private val sent = Regex("""ETB\s?([\d,\.]+)[\s\S]*?sent to\s+(.+?)\s*\(""", RegexOption.IGNORE_CASE)
    private val bal = Regex("""balance is\s+ETB\s?([\d,\.]+)""", RegexOption.IGNORE_CASE)

    private fun clean(s: String) = s.trim().trimEnd('.', ',')

    fun fmt(s: String): String {
        val v = s.replace(",", "").toDoubleOrNull() ?: return s
        return if (v == Math.floor(v)) String.format(Locale.US, "%,d", v.toLong())
        else String.format(Locale.US, "%,.2f", v)
    }

    private fun twoNames(s: String) = s.trim().split(Regex("\\s+")).take(2).joinToString(" ")

    fun parse(text: String): Payment? {
        val b = bal.find(text)?.groupValues?.get(1)?.let { clean(it) } ?: ""
        recv.find(text)?.let {
            return Payment(true, fmt(clean(it.groupValues[1])), twoNames(it.groupValues[2]), if (b.isEmpty()) "" else fmt(b))
        }
        sent.find(text)?.let {
            return Payment(false, fmt(clean(it.groupValues[1])), twoNames(it.groupValues[2]), if (b.isEmpty()) "" else fmt(b))
        }
        return null
    }
}
