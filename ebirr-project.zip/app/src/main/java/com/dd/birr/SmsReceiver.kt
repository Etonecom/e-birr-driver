package com.dd.birr

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i)
        if (msgs.isNullOrEmpty()) return
        val addr = msgs[0].originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val src = Store.sources(c).firstOrNull { it.id.equals(addr, true) } ?: return
        val p = Parser.parse(body) ?: return
        if (p.income && !src.inn) return
        if (!p.income && !src.out) return
        Notifier.show(c, p)
    }
}
