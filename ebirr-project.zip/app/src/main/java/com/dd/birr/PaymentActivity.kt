package com.dd.birr

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class PaymentActivity : Activity() {
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        build()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        tts?.shutdown(); tts = null
        build()
    }

    private fun build() {
        val income = intent.getBooleanExtra("income", true)
        val amount = intent.getStringExtra("amount") ?: ""
        val name = intent.getStringExtra("name") ?: ""
        val balance = intent.getStringExtra("balance") ?: ""
        val fs = Store.fontSize(this)
        val color = if (income) Store.textColor(this) else 0xFFFF7A6B.toInt()

        fun tv(s: String, size: Float, bold: Boolean) = TextView(this).apply {
            text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(null, Typeface.BOLD)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Store.bgColor(this@PaymentActivity))
            setPadding(30, 30, 30, 30)
            setOnClickListener { finish() }
        }
        root.addView(tv((if (income) "+" else "-") + amount, fs.toFloat(), true))
        root.addView(tv("ብር", fs * 0.35f, true))
        root.addView(tv(name, fs * 0.4f, true))
        if (balance.isNotEmpty()) root.addView(tv("ቀሪ ሂሳብ: $balance ብር", fs * 0.2f, false))
        setContentView(root)

        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ finish() }, 12000)

        if (Store.tts(this) && income) {
            tts = TextToSpeech(this) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    val r = tts?.setLanguage(Locale("am"))
                    if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts?.setLanguage(Locale.US)
                    }
                    tts?.speak("$name, $amount birr", TextToSpeech.QUEUE_FLUSH, null, "pay")
                }
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tts?.shutdown()
        super.onDestroy()
    }
}
