package com.dd.birr

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Src(val id: String, var inn: Boolean, var out: Boolean)

object Store {
    val TEXT_COLORS = listOf(
        "አረንጓዴ" to 0xFF3FD68B.toInt(), "ነጭ" to 0xFFFFFFFF.toInt(), "ቢጫ" to 0xFFFFD54F.toInt(),
        "ሰማያዊ" to 0xFF4FC3F7.toInt(), "ጥቁር" to 0xFF000000.toInt()
    )
    val BG_COLORS = listOf(
        "ጥቁር" to 0xFF000000.toInt(), "ጥቁር አረንጓዴ" to 0xFF07120D.toInt(),
        "ነጭ" to 0xFFFFFFFF.toInt(), "ጥቁር ሰማያዊ" to 0xFF0A1A2F.toInt()
    )

    private fun p(c: Context) = c.getSharedPreferences("birr", Context.MODE_PRIVATE)

    fun sources(c: Context): MutableList<Src> {
        val l = mutableListOf<Src>()
        val a = JSONArray(p(c).getString("src", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            l.add(Src(o.getString("id"), o.getBoolean("in"), o.getBoolean("out")))
        }
        return l
    }

    fun saveSources(c: Context, l: List<Src>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("in", it.inn).put("out", it.out)) }
        p(c).edit().putString("src", a.toString()).apply()
    }

    fun fontSize(c: Context) = p(c).getInt("fs", 84)
    fun setFontSize(c: Context, v: Int) = p(c).edit().putInt("fs", v).apply()
    fun textColor(c: Context) = p(c).getInt("tc", TEXT_COLORS[0].second)
    fun setTextColor(c: Context, v: Int) = p(c).edit().putInt("tc", v).apply()
    fun bgColor(c: Context) = p(c).getInt("bc", BG_COLORS[0].second)
    fun setBgColor(c: Context, v: Int) = p(c).edit().putInt("bc", v).apply()
    fun tts(c: Context) = p(c).getBoolean("tts", false)
    fun setTts(c: Context, v: Boolean) = p(c).edit().putBoolean("tts", v).apply()
}
